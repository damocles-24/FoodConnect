"use strict";

/* =========================================================
   API PATHS
   ========================================================= */

const API_BASE = "/api";

const API = {
    getApplication:
        `${API_BASE}/get_restaurant_application.php`,

    saveApplication:
        `${API_BASE}/save_restaurant_application.php`,

    uploadRestaurantLogo:
        `${API_BASE}/upload_restaurant_logo.php`,

    verificationStatus:
        `${API_BASE}/get_partner_verification_status.php`,

    requestVerificationResend:
        `${API_BASE}/request_partner_verification_resend.php`,

    logout:
        `${API_BASE}/logout.php`
};

/* =========================================================
   DOM ELEMENTS
   ========================================================= */

const loadingState =
    document.getElementById("loadingState");

const restaurantForm =
    document.getElementById("restaurantForm");

const statusBanner =
    document.getElementById("statusBanner");

const partnerEmailVerificationBanner =
    document.getElementById(
        "partnerEmailVerificationBanner"
    );

const partnerVerificationIcon =
    document.getElementById(
        "partnerVerificationIcon"
    );

const partnerVerificationBadge =
    document.getElementById(
        "partnerVerificationBadge"
    );

const partnerVerificationTitle =
    document.getElementById(
        "partnerVerificationTitle"
    );

const partnerVerificationText =
    document.getElementById(
        "partnerVerificationText"
    );

const partnerVerificationMeta =
    document.getElementById(
        "partnerVerificationMeta"
    );

const requestPartnerVerificationButton =
    document.getElementById(
        "requestPartnerVerificationButton"
    );

const wizardStatus =
    document.getElementById("wizardStatus");

const wizardStepLabel =
    document.getElementById("wizardStepLabel");

const wizardStepTitle =
    document.getElementById("wizardStepTitle");

const wizardProgressBar =
    document.getElementById("wizardProgressBar");

const businessHoursContainer =
    document.getElementById(
        "businessHoursContainer"
    );

const businessHoursError =
    document.getElementById(
        "businessHoursError"
    );

    const restaurantLogoInput =
    document.getElementById(
        "restaurantLogo"
    );

const restaurantLogoPathInput =
    document.getElementById(
        "restaurantLogoPath"
    );

const logoPreview =
    document.getElementById(
        "logoPreview"
    );

const logoPreviewImage =
    document.getElementById(
        "logoPreviewImage"
    );

const logoPreviewPlaceholder =
    document.getElementById(
        "logoPreviewPlaceholder"
    );

const restaurantLogoError =
    document.getElementById(
        "restaurantLogoError"
    );

const removeLogoButton =
    document.getElementById(
        "removeLogoButton"
    );

const restaurantNameInput =
    document.getElementById(
        "restaurantName"
    );

const cuisineInput =
    document.getElementById(
        "cuisine"
    );

const restaurantContactInput =
    document.getElementById(
        "restaurantContact"
    );

const businessEmailInput =
    document.getElementById(
        "businessEmail"
    );


const restaurantDescriptionInput =
    document.getElementById(
        "restaurantDescription"
    );

const restaurantAddressInput =
    document.getElementById(
        "restaurantAddress"
    );

const provinceInput =
    document.getElementById(
        "province"
    );

const cityMunicipalityInput =
    document.getElementById(
        "cityMunicipality"
    );

const barangayInput =
    document.getElementById(
        "barangay"
    );

const postalCodeInput =
    document.getElementById(
        "postalCode"
    );

const deliveryFeeGroup =
    document.getElementById(
        "deliveryFeeGroup"
    );

const deliveryFeeInput =
    document.getElementById(
        "deliveryFee"
    );

const deliveryPricingTypeInput =
    document.getElementById(
        "deliveryPricingType"
    );

const fixedPricingFields =
    document.getElementById(
        "fixedPricingFields"
    );

const distancePricingFields =
    document.getElementById(
        "distancePricingFields"
    );

const tieredPricingFields =
    document.getElementById(
        "tieredPricingFields"
    );

const deliveryBaseFeeInput =
    document.getElementById(
        "deliveryBaseFee"
    );

const deliveryIncludedKmInput =
    document.getElementById(
        "deliveryIncludedKm"
    );

const deliveryExtraFeePerKmInput =
    document.getElementById(
        "deliveryExtraFeePerKm"
    );

const deliveryTiersContainer =
    document.getElementById(
        "deliveryTiersContainer"
    );

const addDeliveryTierButton =
    document.getElementById(
        "addDeliveryTierButton"
    );

const deliveryPricingError =
    document.getElementById(
        "deliveryPricingError"
    );

const descriptionCounter =
    document.getElementById(
        "descriptionCounter"
    );

const deliveryOptionsError =
    document.getElementById(
        "deliveryOptionsError"
    );

const confirmationCheckbox =
    document.getElementById(
        "confirmationCheckbox"
    );

const confirmationError =
    document.getElementById(
        "confirmationError"
    );

const saveDraftButton =
    document.getElementById(
        "saveDraftButton"
    );

const nextButton =
    document.getElementById(
        "nextButton"
    );

const backButton =
    document.getElementById(
        "backButton"
    );

const submitButton =
    document.getElementById(
        "submitButton"
    );

const logoutButton =
    document.getElementById(
        "logoutButton"
    );

const applyMondayButton =
    document.getElementById(
        "applyMondayButton"
    );

const toastContainer =
    document.getElementById(
        "toastContainer"
    );

const submissionModal =
    document.getElementById(
        "submissionModal"
    );

const modalContinueButton =
    document.getElementById(
        "modalContinueButton"
    );

const submittedState =
    document.getElementById(
        "submittedState"
    );

    const customerPreviewLogoImage =
    document.getElementById(
        "customerPreviewLogoImage"
    );

const customerPreviewLogoPlaceholder =
    document.getElementById(
        "customerPreviewLogoPlaceholder"
    );

const customerPreviewName =
    document.getElementById(
        "customerPreviewName"
    );

const customerPreviewCuisine =
    document.getElementById(
        "customerPreviewCuisine"
    );

const customerPreviewStatus =
    document.getElementById(
        "customerPreviewStatus"
    );

const customerPreviewTodayHours =
    document.getElementById(
        "customerPreviewTodayHours"
    );

const customerPreviewDescription =
    document.getElementById(
        "customerPreviewDescription"
    );

const customerPreviewAddress =
    document.getElementById(
        "customerPreviewAddress"
    );

const customerPreviewServices =
    document.getElementById(
        "customerPreviewServices"
    );

const customerPreviewMinimumOrder =
    document.getElementById(
        "customerPreviewMinimumOrder"
    );

const customerPreviewDeliveryFee =
    document.getElementById(
        "customerPreviewDeliveryFee"
    );

const applicationReview =
    document.getElementById(
        "applicationReview"
    );

    const reviewLogo =
    document.getElementById(
        "reviewLogo"
    );

const reviewLogoImage =
    document.getElementById(
        "reviewLogoImage"
    );

const reviewLogoPlaceholder =
    document.getElementById(
        "reviewLogoPlaceholder"
    );

const reviewRestaurantName =
    document.getElementById(
        "reviewRestaurantName"
    );

const reviewCuisine =
    document.getElementById(
        "reviewCuisine"
    );

const reviewRestaurantContact =
    document.getElementById(
        "reviewRestaurantContact"
    );

const reviewBusinessEmail =
    document.getElementById(
        "reviewBusinessEmail"
    );


const reviewAddress =
    document.getElementById(
        "reviewAddress"
    );

const reviewBusinessHours =
    document.getElementById(
        "reviewBusinessHours"
    );

const reviewDeliveryOptions =
    document.getElementById(
        "reviewDeliveryOptions"
    );

const reviewDeliveryPricing =
    document.getElementById(
        "reviewDeliveryPricing"
    );

const wizardSteps =
    Array.from(
        document.querySelectorAll(
            ".wizard-step"
        )
    );

const progressItems =
    Array.from(
        document.querySelectorAll(
            "[data-progress-step]"
        )
    );

const reviewEditButtons =
    Array.from(
        document.querySelectorAll(
            "[data-edit-step]"
        )
    );

const deliveryOptionInputs =
    Array.from(
        document.querySelectorAll(
            'input[name="delivery_options"]'
        )
    );

/* =========================================================
   PAGE STATE
   ========================================================= */

const DAYS = [
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday",
    "Sunday"
];

const TOTAL_STEPS = 5;

const STEP_TITLES = {
    1: "Restaurant details",
    2: "Business location",
    3: "Business hours",
    4: "Order services",
    5: "Review application"
};

const DELIVERY_OPTION_LABELS = {
    "dine-in":
        "Dine-in",

    takeout:
        "Takeout",

    delivery:
        "Delivery"
};

let currentApplicationStatus =
    "draft";

let currentStep =
    1;

let isSubmitting =
    false;

let partnerVerificationLoaded = false;
let ownerEmailVerified = false;
let partnerVerificationState = null;
let partnerVerificationPollTimer = null;
let partnerVerificationRequestBusy = false;
let partnerVerificationInitialized = false;

/* =========================================================
   INITIALIZATION
   ========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    initializePage
);
const openCustomerPagePreview =
    document.getElementById(
        "openCustomerPagePreview"
    );
async function initializePage() {
    renderBusinessHours();
    bindEvents();
    updateDescriptionCounter();
    updateWizardButtons();

    if (window.PHAddressDropdown) {
        await window.PHAddressDropdown.bindCascadingSelects({
            areaSelect: provinceInput,
            localitySelect: cityMunicipalityInput,
            barangaySelect: barangayInput
        });
    }

    await loadApplication();
}

/* =========================================================
   EVENT BINDINGS
   ========================================================= */

function bindEvents() {

    openCustomerPagePreview?.addEventListener(
    "click",
    openRealCustomerPreview
);

    requestPartnerVerificationButton?.addEventListener(
        "click",
        handlePartnerVerificationResendRequest
    );

    restaurantForm.addEventListener(
        "submit",
        handleSubmitApplication
    );

    saveDraftButton.addEventListener(
        "click",
        handleSaveDraft
    );

    nextButton.addEventListener(
        "click",
        handleNextStep
    );

    backButton.addEventListener(
        "click",
        handlePreviousStep
    );

    logoutButton.addEventListener(
        "click",
        handleLogout
    );

    applyMondayButton.addEventListener(
        "click",
        applyMondayScheduleToAll
    );

    restaurantLogoInput.addEventListener(
    "change",
    handleRestaurantLogoChange
);

removeLogoButton.addEventListener(
    "click",
    removeRestaurantLogo
);

    restaurantDescriptionInput.addEventListener(
        "input",
        updateDescriptionCounter
    );

    postalCodeInput.addEventListener(
        "input",
        () => {
            postalCodeInput.value =
                postalCodeInput.value.replace(
                    /[^0-9]/g,
                    ""
                );

            clearFieldError(
                postalCodeInput
            );

            updateWizardButtons();
        }
    );

    [
        restaurantNameInput,
        cuisineInput,
        restaurantContactInput,
        businessEmailInput,
        restaurantDescriptionInput,
        restaurantAddressInput,
        provinceInput,
        cityMunicipalityInput,
        barangayInput,
        deliveryFeeInput,
        deliveryBaseFeeInput,
        deliveryIncludedKmInput,
        deliveryExtraFeePerKmInput
    ].filter(Boolean).forEach((field) => {
        field.addEventListener(
            "input",
            () => {
                clearFieldError(field);
                updateWizardButtons();
            }
        );

        field.addEventListener(
            "change",
            () => {
                clearFieldError(field);
                updateWizardButtons();
            }
        );
    });

    deliveryPricingTypeInput?.addEventListener(
        "change",
        () => {
            updateDeliveryPricingFields();
            updateWizardButtons();
        }
    );

    addDeliveryTierButton?.addEventListener(
        "click",
        () => {
            if (!deliveryTiersContainer) {
                return;
            }

            if (deliveryTiersContainer.children.length >= 10) {
                if (deliveryPricingError) {
                    deliveryPricingError.textContent =
                        "A maximum of 10 delivery tiers is allowed.";
                }
                return;
            }

            const existingRows =
                Array.from(
                    deliveryTiersContainer.querySelectorAll(
                        ".delivery-tier-row"
                    )
                );

            const lastRow =
                existingRows[existingRows.length - 1];

            const lastKm =
                Number(
                    lastRow?.querySelector(
                        ".delivery-tier-km"
                    )?.value || 0
                );

            const lastFee =
                Number(
                    lastRow?.querySelector(
                        ".delivery-tier-fee"
                    )?.value || 0
                );

            deliveryTiersContainer.appendChild(
                createDeliveryTierRow(
                    {
                        up_to_km:
                            Math.min(
                                100,
                                Math.max(1, lastKm + 3)
                            ),
                        fee:
                            Math.max(0, lastFee + 50)
                    },
                    existingRows.length
                )
            );

            refreshDeliveryTierLabels();
            clearDeliveryPricingError();
            updateWizardButtons();
        }
    );

    deliveryOptionInputs.forEach(
        (checkbox) => {
            checkbox.addEventListener(
                "change",
                () => {
                    clearDeliveryOptionsError();
                    updateDeliveryFeeVisibility();
                    updateWizardButtons();
                }
            );
        }
    );

    confirmationCheckbox.addEventListener(
        "change",
        () => {
            clearConfirmationError();
            updateWizardButtons();
        }
    );

    reviewEditButtons.forEach(
        (button) => {
            button.addEventListener(
                "click",
                handleReviewEdit
            );
        }
    );

    modalContinueButton.addEventListener(
        "click",
        () => {
            submissionModal.classList.add(
                "hidden"
            );

            window.scrollTo({
                top: 0,
                behavior: "smooth"
            });
        }
    );

    document.addEventListener(
        "foodconnect:verification-documents-changed",
        () => {
            updateWizardButtons();
        }
    );
}

async function openRealCustomerPreview() {
    if (isSubmitting) {
        return;
    }

    clearValidationErrors();

    const valid =
        validateRequiredInformation(
            true
        );

    if (!valid) {
        openFirstInvalidStep();

        showToast(
            "Complete required information",
            "Save the required restaurant and location details before opening the customer preview.",
            "error"
        );

        focusFirstInvalidField();

        return;
    }

    const previewWindow =
        window.open(
            "",
            "_blank"
        );

    if (!previewWindow) {
        showToast(
            "Preview blocked",
            "Allow pop-ups for this site, then try opening the preview again.",
            "error"
        );

        return;
    }

    previewWindow.document.title =
        "Loading Restaurant Preview";

    const previewFontLink =
        previewWindow.document.createElement("link");

    previewFontLink.rel = "stylesheet";
    previewFontLink.href = "https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap";
    previewWindow.document.head.appendChild(
        previewFontLink
    );

    previewWindow.document.body.innerHTML = `
        <div
            style="
                min-height: 100vh;
                display: grid;
                place-items: center;
                margin: 0;
                font-family: "Poppins", sans-serif;
                background: #111111;
                color: #ffffff;
            "
        >
            Loading customer preview...
        </div>
    `;

    const saved =
        await saveApplication(
            collectFormData(
                "save"
            ),
            "save"
        );

    if (saved !== true) {
        previewWindow.close();

        return;
    }

    previewWindow.location.href =
        "/frontend/html/restaurant.html?preview=owner";
}

/* =========================================================
   BUSINESS HOURS UI
   ========================================================= */

function renderBusinessHours() {
    businessHoursContainer.innerHTML =
        DAYS.map((day) => {
            const dayKey =
                day.toLowerCase();

            return `
                <div
                    class="hours-row"
                    data-day="${escapeHtml(day)}"
                >
                    <div class="hours-day">
                        ${escapeHtml(day)}
                    </div>

                    <input
                        type="time"
                        class="hours-input hours-open"
                        id="${dayKey}Open"
                        value="08:00"
                        aria-label="${escapeHtml(day)} opening time"
                    >

                    <input
                        type="time"
                        class="hours-input hours-close"
                        id="${dayKey}Close"
                        value="20:00"
                        aria-label="${escapeHtml(day)} closing time"
                    >

                    <label class="closed-label">
                        <input
                            type="checkbox"
                            class="hours-closed"
                            id="${dayKey}Closed"
                        >

                        Closed
                    </label>
                </div>
            `;
        }).join("");

    document
        .querySelectorAll(".hours-closed")
        .forEach((checkbox) => {
            checkbox.addEventListener(
                "change",
                handleClosedDayChange
            );
        });

    document
        .querySelectorAll(
            ".hours-open, .hours-close"
        )
        .forEach((input) => {
            input.addEventListener(
                "input",
                () => {
                    clearBusinessHoursError();
                    updateWizardButtons();
                }
            );

            input.addEventListener(
                "change",
                () => {
                    clearBusinessHoursError();
                    updateWizardButtons();
                }
            );
        });
}

function handleClosedDayChange(event) {
    const checkbox =
        event.currentTarget;

    const row =
        checkbox.closest(".hours-row");

    if (!row) {
        return;
    }

    const openInput =
        row.querySelector(".hours-open");

    const closeInput =
        row.querySelector(".hours-close");

    openInput.disabled =
        checkbox.checked;

    closeInput.disabled =
        checkbox.checked;

    row.classList.remove(
        "invalid-row"
    );

    openInput.classList.remove(
        "invalid"
    );

    closeInput.classList.remove(
        "invalid"
    );

    clearBusinessHoursError();
    updateWizardButtons();
}

function applyMondayScheduleToAll() {
    const mondayRow =
        document.querySelector(
            '.hours-row[data-day="Monday"]'
        );

    if (!mondayRow) {
        return;
    }

    const mondayOpen =
        mondayRow.querySelector(
            ".hours-open"
        ).value;

    const mondayClose =
        mondayRow.querySelector(
            ".hours-close"
        ).value;

    const mondayClosed =
        mondayRow.querySelector(
            ".hours-closed"
        ).checked;

    document
        .querySelectorAll(".hours-row")
        .forEach((row) => {
            const openInput =
                row.querySelector(
                    ".hours-open"
                );

            const closeInput =
                row.querySelector(
                    ".hours-close"
                );

            const closedInput =
                row.querySelector(
                    ".hours-closed"
                );

            openInput.value =
                mondayOpen;

            closeInput.value =
                mondayClose;

            closedInput.checked =
                mondayClosed;

            openInput.disabled =
                mondayClosed;

            closeInput.disabled =
                mondayClosed;

            row.classList.remove(
                "invalid-row"
            );

            openInput.classList.remove(
                "invalid"
            );

            closeInput.classList.remove(
                "invalid"
            );
        });

    clearBusinessHoursError();
    updateWizardButtons();

    showToast(
        "Schedule copied",
        "Monday's schedule was applied to every day.",
        "success"
    );
}

/* =========================================================
   LOAD APPLICATION
   ========================================================= */

async function loadApplication() {
    try {
        const response =
            await fetch(
                API.getApplication,
                {
                    method: "GET",
                    credentials: "include",
                    headers: {
                        "Accept":
                            "application/json"
                    }
                }
            );

        const result =
            await parseJsonResponse(
                response
            );

        if (response.status === 401) {
            window.location.href =
                "/?open=partner-portal";

            return;
        }

        if (response.status === 403) {
            throw new Error(
                result.message ||
                "Only restaurant owners can access this page."
            );
        }

        if (
            !response.ok ||
            !result.success
        ) {
            throw new Error(
                result.message ||
                "Unable to load the restaurant application."
            );
        }

        if (result.has_restaurant) {
            redirectApprovedOwner(
                result.restaurant
            );

            return;
        }

        populateApplication(
            result.application || {}
        );

        await loadPartnerVerificationStatus(
            true
        );

        showForm();
    } catch (error) {
        console.error(
            "Restaurant application load error:",
            error
        );

        loadingState.innerHTML = `
            <div class="status-banner status-rejected">
                <strong>
                    Unable to load restaurant setup.
                </strong>

                <br>

                ${escapeHtml(error.message)}
            </div>
        `;
    }
}

/* =========================================================
   PARTNER EMAIL VERIFICATION
   ========================================================= */

function stopPartnerVerificationPolling() {
    if (partnerVerificationPollTimer) {
        window.clearTimeout(
            partnerVerificationPollTimer
        );

        partnerVerificationPollTimer = null;
    }
}

function schedulePartnerVerificationPolling(
    delay = 15000
) {
    stopPartnerVerificationPolling();

    if (ownerEmailVerified) {
        return;
    }

    partnerVerificationPollTimer =
        window.setTimeout(
            () => {
                loadPartnerVerificationStatus(
                    false
                );
            },
            delay
        );
}

function setPartnerVerificationBannerState(
    stateClass = ""
) {
    if (!partnerEmailVerificationBanner) {
        return;
    }

    partnerEmailVerificationBanner.classList.remove(
        "is-waiting",
        "is-sent",
        "is-danger"
    );

    if (stateClass) {
        partnerEmailVerificationBanner.classList.add(
            stateClass
        );
    }
}

function renderPartnerVerificationState(
    verification = {}
) {
    partnerVerificationState =
        verification || {};

    const wasVerified =
        ownerEmailVerified;

    const hadVerificationState =
        partnerVerificationInitialized;

    partnerVerificationInitialized = true;
    partnerVerificationLoaded = true;
    ownerEmailVerified =
        Boolean(
            verification.is_verified
        );

    if (ownerEmailVerified) {
        stopPartnerVerificationPolling();

        partnerEmailVerificationBanner
            ?.classList.add("hidden");

        if (
            currentApplicationStatus ===
            "email_pending"
        ) {
            currentApplicationStatus =
                "draft";

            renderApplicationStatus(
                "draft"
            );
        }

        updateWizardButtons();

        if (
            hadVerificationState &&
            !wasVerified
        ) {
            showToast(
                "Email verified",
                "Your owner email is verified. You can now complete restaurant setup when all required information is ready.",
                "success"
            );
        }

        return;
    }

    const request =
        verification.request &&
        typeof verification.request === "object"
            ? verification.request
            : null;

    const requestStatus =
        String(
            request?.status || "none"
        ).toLowerCase();

    const maskedEmail =
        String(
            verification.registered_email_masked ||
            "your registered owner email"
        );

    const linkExpired =
        Boolean(
            verification.link_expired
        );

    const canRequest =
        Boolean(
            verification.can_request_resend
        );

    partnerEmailVerificationBanner
        ?.classList.remove("hidden");

    setPartnerVerificationBannerState("");

    if (partnerVerificationIcon) {
        partnerVerificationIcon.textContent =
            "✉";
    }

    if (partnerVerificationBadge) {
        partnerVerificationBadge.textContent =
            "Email verification pending";
    }

    if (partnerVerificationTitle) {
        partnerVerificationTitle.textContent =
            linkExpired
                ? "Your verification link expired"
                : "Verify your owner email";
    }

    if (partnerVerificationText) {
        partnerVerificationText.textContent =
            linkExpired
                ? "Your restaurant setup progress is still saved. Request a new verification email from the FoodConnect administrator before completing setup."
                : "You can continue editing and saving your restaurant setup. Email verification is required only before you complete setup.";
    }

    if (partnerVerificationMeta) {
        partnerVerificationMeta.textContent =
            `Registered email: ${maskedEmail}`;
    }

    if (requestPartnerVerificationButton) {
        requestPartnerVerificationButton.disabled =
            partnerVerificationRequestBusy ||
            !canRequest;

        requestPartnerVerificationButton.textContent =
            "Request new verification email";
    }

    if (
        requestStatus === "pending" ||
        requestStatus === "processing"
    ) {
        setPartnerVerificationBannerState(
            "is-waiting"
        );

        if (partnerVerificationBadge) {
            partnerVerificationBadge.textContent =
                requestStatus === "processing"
                    ? "Administrator processing"
                    : "Waiting for administrator";
        }

        if (partnerVerificationTitle) {
            partnerVerificationTitle.textContent =
                "Verification email request submitted";
        }

        if (partnerVerificationText) {
            partnerVerificationText.textContent =
                "A FoodConnect administrator must approve the request before a replacement verification email can be sent. You do not need to submit another request.";
        }

        if (requestPartnerVerificationButton) {
            requestPartnerVerificationButton.disabled =
                true;

            requestPartnerVerificationButton.textContent =
                requestStatus === "processing"
                    ? "Administrator processing"
                    : "Waiting for administrator";
        }
    } else if (requestStatus === "sent") {
        setPartnerVerificationBannerState(
            "is-sent"
        );

        if (partnerVerificationIcon) {
            partnerVerificationIcon.textContent =
                "✓";
        }

        if (partnerVerificationBadge) {
            partnerVerificationBadge.textContent =
                "New email sent";
        }

        if (partnerVerificationTitle) {
            partnerVerificationTitle.textContent =
                "Check your verification email";
        }

        if (partnerVerificationText) {
            partnerVerificationText.textContent =
                "The administrator sent a new verification link. Check your Inbox and Spam/Junk folder, then open the link to verify your owner email.";
        }

        if (partnerVerificationMeta) {
            partnerVerificationMeta.textContent =
                `Sent to ${maskedEmail}. The replacement link is valid for 24 hours.`;
        }

        if (requestPartnerVerificationButton) {
            requestPartnerVerificationButton.disabled =
                true;

            requestPartnerVerificationButton.textContent =
                "Verification email sent";
        }
    } else if (requestStatus === "send_failed") {
        setPartnerVerificationBannerState(
            "is-danger"
        );

        if (partnerVerificationBadge) {
            partnerVerificationBadge.textContent =
                "Email delivery needs retry";
        }

        if (partnerVerificationTitle) {
            partnerVerificationTitle.textContent =
                "The administrator needs to retry delivery";
        }

        if (partnerVerificationText) {
            partnerVerificationText.textContent =
                "Your request was handled, but the verification email could not be delivered. The administrator can retry the same request; you do not need to submit another one.";
        }

        if (requestPartnerVerificationButton) {
            requestPartnerVerificationButton.disabled =
                true;

            requestPartnerVerificationButton.textContent =
                "Waiting for administrator retry";
        }
    } else if (requestStatus === "rejected") {
        setPartnerVerificationBannerState(
            "is-danger"
        );

        if (partnerVerificationBadge) {
            partnerVerificationBadge.textContent =
                "Request not approved";
        }

        if (partnerVerificationTitle) {
            partnerVerificationTitle.textContent =
                "Verification resend request rejected";
        }

        if (partnerVerificationText) {
            partnerVerificationText.textContent =
                String(
                    request?.rejection_reason ||
                    "The administrator did not approve the latest request. Contact FoodConnect if you still need a replacement verification link."
                );
        }

        if (requestPartnerVerificationButton) {
            requestPartnerVerificationButton.disabled =
                !canRequest ||
                partnerVerificationRequestBusy;

            requestPartnerVerificationButton.textContent =
                canRequest
                    ? "Request again"
                    : "Contact administrator";
        }
    }

    updateWizardButtons();
    schedulePartnerVerificationPolling();
}

async function loadPartnerVerificationStatus(
    showFailure = false
) {
    try {
        const response = await fetch(
            API.verificationStatus,
            {
                method: "GET",
                credentials: "include",
                cache: "no-store",
                headers: {
                    "Accept":
                        "application/json"
                }
            }
        );

        const result =
            await parseJsonResponse(
                response
            );

        if (response.status === 401) {
            window.location.href =
                "/?open=partner-portal";

            return false;
        }

        if (
            !response.ok ||
            !result.success ||
            !result.email_verification
        ) {
            throw new Error(
                result.message ||
                "Unable to check email verification status."
            );
        }

        renderPartnerVerificationState(
            result.email_verification
        );

        return true;
    } catch (error) {
        console.error(
            "Partner verification status error:",
            error
        );

        partnerVerificationLoaded = false;
        ownerEmailVerified = false;

        if (showFailure) {
            partnerEmailVerificationBanner
                ?.classList.remove("hidden");

            setPartnerVerificationBannerState(
                "is-danger"
            );

            if (partnerVerificationBadge) {
                partnerVerificationBadge.textContent =
                    "Verification status unavailable";
            }

            if (partnerVerificationTitle) {
                partnerVerificationTitle.textContent =
                    "FoodConnect could not confirm your email status";
            }

            if (partnerVerificationText) {
                partnerVerificationText.textContent =
                    "You can keep editing and saving your setup, but completing setup is temporarily disabled until the verification status can be checked.";
            }

            if (partnerVerificationMeta) {
                partnerVerificationMeta.textContent =
                    "Refresh the page or try again shortly.";
            }

            if (requestPartnerVerificationButton) {
                requestPartnerVerificationButton.disabled =
                    true;

                requestPartnerVerificationButton.textContent =
                    "Status unavailable";
            }
        }

        updateWizardButtons();
        schedulePartnerVerificationPolling(
            20000
        );

        return false;
    }
}

async function handlePartnerVerificationResendRequest() {
    if (
        partnerVerificationRequestBusy ||
        ownerEmailVerified ||
        requestPartnerVerificationButton?.disabled
    ) {
        return;
    }

    partnerVerificationRequestBusy = true;

    if (requestPartnerVerificationButton) {
        requestPartnerVerificationButton.disabled =
            true;

        requestPartnerVerificationButton.textContent =
            "Submitting request...";
    }

    try {
        const response = await fetch(
            API.requestVerificationResend,
            {
                method: "POST",
                credentials: "include",
                headers: {
                    "Content-Type":
                        "application/json",
                    "Accept":
                        "application/json"
                },
                body: JSON.stringify({})
            }
        );

        const result =
            await parseJsonResponse(
                response
            );

        if (response.status === 401) {
            window.location.href =
                "/";
            return;
        }

        if (
            !response.ok ||
            !result.success
        ) {
            throw new Error(
                result.message ||
                "Unable to submit the verification email request."
            );
        }

        showToast(
            "Request submitted",
            result.message ||
                "A FoodConnect administrator must approve the request before a new verification email is sent.",
            "success"
        );

        await loadPartnerVerificationStatus(
            true
        );
    } catch (error) {
        console.error(
            "Partner verification resend request error:",
            error
        );

        showToast(
            "Request not sent",
            error.message ||
                "Unable to submit the verification email request.",
            "error"
        );
    } finally {
        partnerVerificationRequestBusy =
            false;

        if (!ownerEmailVerified) {
            await loadPartnerVerificationStatus(
                false
            );
        }
    }
}

function populateApplication(application) {
    currentApplicationStatus =
        String(
            application.application_status ||
            "draft"
        ).toLowerCase();

    restaurantLogoPathInput.value =
    application.logo_path || "";

renderRestaurantLogo(
    application.logo_path || ""
);

    restaurantNameInput.value =
        application.restaurant_name || "";

    cuisineInput.value =
        application.cuisine || "";

    restaurantContactInput.value =
        window.FoodConnectPhone.toLocalDigits(application.restaurant_contact);

    businessEmailInput.value =
        application.business_email || "";

    restaurantDescriptionInput.value =
        application.restaurant_description || "";

    restaurantAddressInput.value =
        application.restaurant_address || "";

    provinceInput.value =
        application.province || "";

    cityMunicipalityInput.value =
        application.city_municipality || "";

    barangayInput.value =
        application.barangay || "";

    if (window.PHAddressDropdown) {
        window.PHAddressDropdown.setCascadingValues({
            areaSelect: provinceInput,
            localitySelect: cityMunicipalityInput,
            barangaySelect: barangayInput,
            areaName: application.province || "",
            localityName: application.city_municipality || "",
            barangayName: application.barangay || ""
        });
    }

    postalCodeInput.value =
        application.postal_code || "";

    populateBusinessHours(
        application.business_hours
    );

    populateDeliveryOptions(
        application.delivery_options
    );

    const applicationPricingType =
        normalizeDeliveryPricingType(
            application.delivery_pricing_type ||
            "fixed"
        );

    const applicationPricing =
        application.delivery_pricing &&
        typeof application.delivery_pricing === "object"
            ? application.delivery_pricing
            : {};

    if (deliveryPricingTypeInput) {
        deliveryPricingTypeInput.value =
            applicationPricingType;
    }

    if (deliveryFeeInput) {
        deliveryFeeInput.value =
            formatMoneyInput(
                applicationPricing.fixed_fee ??
                application.delivery_fee ??
                0
            );
    }

    if (deliveryBaseFeeInput) {
        deliveryBaseFeeInput.value =
            formatMoneyInput(
                applicationPricing.base_fee ??
                application.delivery_fee ??
                70
            );
    }

    if (deliveryIncludedKmInput) {
        deliveryIncludedKmInput.value =
            String(
                applicationPricing.included_km ??
                5
            );
    }

    if (deliveryExtraFeePerKmInput) {
        deliveryExtraFeePerKmInput.value =
            formatMoneyInput(
                applicationPricing.extra_fee_per_km ??
                10
            );
    }

    renderDeliveryTiers(
        Array.isArray(applicationPricing.tiers)
            ? applicationPricing.tiers
            : []
    );

    updateDeliveryFeeVisibility();

    updateDescriptionCounter();

    renderApplicationStatus(
        currentApplicationStatus,
        application.rejection_reason
    );

    applyStatusRestrictions(
        currentApplicationStatus
    );
}

function normalizeDeliveryPricingType(value) {
    const type =
        String(value || "fixed")
            .trim()
            .toLowerCase();

    return ["fixed", "distance", "tiered"].includes(type)
        ? type
        : "fixed";
}

function isDeliveryServiceSelected() {
    return deliveryOptionInputs.some(
        (checkbox) =>
            checkbox.checked &&
            checkbox.value === "delivery"
    );
}

function clearDeliveryPricingError() {
    if (deliveryPricingError) {
        deliveryPricingError.textContent = "";
    }

    deliveryFeeGroup?.classList.remove(
        "invalid-section"
    );
}

function updateDeliveryPricingFields() {
    const type =
        normalizeDeliveryPricingType(
            deliveryPricingTypeInput?.value
        );

    fixedPricingFields?.classList.toggle(
        "hidden",
        type !== "fixed"
    );

    distancePricingFields?.classList.toggle(
        "hidden",
        type !== "distance"
    );

    tieredPricingFields?.classList.toggle(
        "hidden",
        type !== "tiered"
    );

    if (
        type === "tiered" &&
        deliveryTiersContainer &&
        deliveryTiersContainer.children.length === 0
    ) {
        const startingFee =
            Math.max(
                0,
                Number(
                    deliveryFeeInput?.value ||
                    deliveryBaseFeeInput?.value ||
                    70
                ) || 70
            );

        renderDeliveryTiers([
            {
                up_to_km: 5,
                fee: startingFee
            },
            {
                up_to_km: 8,
                fee: startingFee + 50
            }
        ]);
    }

    clearDeliveryPricingError();
}

function createDeliveryTierRow(
    tier = {},
    index = 0
) {
    const row =
        document.createElement("div");

    row.className =
        "delivery-tier-row";

    row.innerHTML = `
        <div>
            <label>Up to distance</label>
            <div class="unit-input">
                <input
                    type="number"
                    class="delivery-tier-km"
                    min="0.1"
                    max="100"
                    step="0.1"
                    value="${Number(tier.up_to_km || (index + 1) * 5)}"
                    aria-label="Tier ${index + 1} maximum distance"
                >
                <span>km</span>
            </div>
        </div>

        <div>
            <label>Delivery fee</label>
            <div class="money-input">
                <span>₱</span>
                <input
                    type="number"
                    class="delivery-tier-fee"
                    min="0"
                    max="9999"
                    step="0.01"
                    value="${Number(tier.fee || 0).toFixed(2)}"
                    aria-label="Tier ${index + 1} delivery fee"
                >
            </div>
        </div>

        <button
            type="button"
            class="delivery-tier-remove"
            aria-label="Remove delivery tier ${index + 1}"
            title="Remove tier"
        >
            <i class="fa-solid fa-trash"></i>
        </button>
    `;

    row
        .querySelectorAll("input")
        .forEach((input) => {
            input.addEventListener(
                "input",
                () => {
                    clearDeliveryPricingError();
                    updateWizardButtons();
                }
            );
        });

    row
        .querySelector(".delivery-tier-remove")
        ?.addEventListener(
            "click",
            () => {
                if (
                    !deliveryTiersContainer ||
                    deliveryTiersContainer.children.length <= 1
                ) {
                    if (deliveryPricingError) {
                        deliveryPricingError.textContent =
                            "Tiered pricing must keep at least one distance tier.";
                    }
                    return;
                }

                row.remove();
                refreshDeliveryTierLabels();
                clearDeliveryPricingError();
                updateWizardButtons();
            }
        );

    return row;
}

function refreshDeliveryTierLabels() {
    deliveryTiersContainer
        ?.querySelectorAll(".delivery-tier-row")
        .forEach((row, index) => {
            row
                .querySelector(".delivery-tier-km")
                ?.setAttribute(
                    "aria-label",
                    `Tier ${index + 1} maximum distance`
                );

            row
                .querySelector(".delivery-tier-fee")
                ?.setAttribute(
                    "aria-label",
                    `Tier ${index + 1} delivery fee`
                );

            row
                .querySelector(".delivery-tier-remove")
                ?.setAttribute(
                    "aria-label",
                    `Remove delivery tier ${index + 1}`
                );
        });
}

function renderDeliveryTiers(tiers = []) {
    if (!deliveryTiersContainer) {
        return;
    }

    deliveryTiersContainer.innerHTML = "";

    const normalizedTiers =
        Array.isArray(tiers) && tiers.length > 0
            ? tiers.slice(0, 10)
            : [
                {
                    up_to_km: 5,
                    fee: Number(
                        deliveryFeeInput?.value || 0
                    ) || 70
                }
            ];

    normalizedTiers.forEach(
        (tier, index) => {
            deliveryTiersContainer.appendChild(
                createDeliveryTierRow(
                    tier,
                    index
                )
            );
        }
    );

    refreshDeliveryTierLabels();
}

function collectDeliveryPricing() {
    const type =
        normalizeDeliveryPricingType(
            deliveryPricingTypeInput?.value
        );

    if (type === "distance") {
        return {
            pricing_type: "distance",
            base_fee:
                Number(
                    deliveryBaseFeeInput?.value || 0
                ),
            included_km:
                Number(
                    deliveryIncludedKmInput?.value || 0
                ),
            extra_fee_per_km:
                Number(
                    deliveryExtraFeePerKmInput?.value || 0
                )
        };
    }

    if (type === "tiered") {
        const tiers = [];

        deliveryTiersContainer
            ?.querySelectorAll(
                ".delivery-tier-row"
            )
            .forEach((row) => {
                tiers.push({
                    up_to_km:
                        Number(
                            row.querySelector(
                                ".delivery-tier-km"
                            )?.value || 0
                        ),
                    fee:
                        Number(
                            row.querySelector(
                                ".delivery-tier-fee"
                            )?.value || 0
                        )
                });
            });

        return {
            pricing_type: "tiered",
            tiers
        };
    }

    return {
        pricing_type: "fixed",
        fixed_fee:
            Number(
                deliveryFeeInput?.value || 0
            )
    };
}

function getLegacyDeliveryFeeFromPricing(
    pricing
) {
    const type =
        normalizeDeliveryPricingType(
            pricing?.pricing_type
        );

    if (type === "distance") {
        return Number(
            pricing?.base_fee || 0
        );
    }

    if (type === "tiered") {
        return Number(
            pricing?.tiers?.[0]?.fee || 0
        );
    }

    return Number(
        pricing?.fixed_fee || 0
    );
}

function validateDeliveryPricing(
    showErrors = true
) {
    if (!isDeliveryServiceSelected()) {
        clearDeliveryPricingError();
        return true;
    }

    const pricing =
        collectDeliveryPricing();

    const setError = (message) => {
        if (showErrors) {
            if (deliveryPricingError) {
                deliveryPricingError.textContent =
                    message;
            }

            deliveryFeeGroup?.classList.add(
                "invalid-section"
            );
        }

        return false;
    };

    const validMoney = (value) =>
        Number.isFinite(value) &&
        value >= 0 &&
        value <= 9999;

    if (pricing.pricing_type === "fixed") {
        return validMoney(pricing.fixed_fee)
            ? true
            : setError(
                "Enter a valid fixed delivery fee from ₱0.00 to ₱9,999.00."
            );
    }

    if (pricing.pricing_type === "distance") {
        if (!validMoney(pricing.base_fee)) {
            return setError(
                "Enter a valid base delivery fee."
            );
        }

        if (
            !Number.isFinite(
                pricing.included_km
            ) ||
            pricing.included_km <= 0 ||
            pricing.included_km > 100
        ) {
            return setError(
                "Included distance must be greater than 0 and not exceed 100 km."
            );
        }

        if (
            !validMoney(
                pricing.extra_fee_per_km
            ) ||
            pricing.extra_fee_per_km <= 0
        ) {
            return setError(
                "Additional fee per kilometer must be greater than ₱0.00."
            );
        }

        clearDeliveryPricingError();
        return true;
    }

    if (
        !Array.isArray(pricing.tiers) ||
        pricing.tiers.length < 1 ||
        pricing.tiers.length > 10
    ) {
        return setError(
            "Add between 1 and 10 delivery distance tiers."
        );
    }

    let previousDistance = 0;

    for (
        let index = 0;
        index < pricing.tiers.length;
        index += 1
    ) {
        const tier = pricing.tiers[index];

        if (
            !Number.isFinite(tier.up_to_km) ||
            tier.up_to_km <= 0 ||
            tier.up_to_km > 100
        ) {
            return setError(
                `Tier ${index + 1} distance must be greater than 0 and not exceed 100 km.`
            );
        }

        if (tier.up_to_km <= previousDistance) {
            return setError(
                "Tier distances must increase from one tier to the next."
            );
        }

        if (!validMoney(tier.fee)) {
            return setError(
                `Enter a valid fee for tier ${index + 1}.`
            );
        }

        previousDistance =
            tier.up_to_km;
    }

    clearDeliveryPricingError();
    return true;
}

function formatDeliveryPricingSummary(
    pricing
) {
    const type =
        normalizeDeliveryPricingType(
            pricing?.pricing_type
        );

    if (type === "distance") {
        return `₱${Number(pricing.base_fee || 0).toFixed(2)} for the first ${Number(pricing.included_km || 0).toFixed(1)} km, then +₱${Number(pricing.extra_fee_per_km || 0).toFixed(2)} per succeeding km.`;
    }

    if (type === "tiered") {
        return (pricing.tiers || [])
            .map(
                (tier) =>
                    `Up to ${Number(tier.up_to_km || 0).toFixed(1)} km = ₱${Number(tier.fee || 0).toFixed(2)}`
            )
            .join(" • ");
    }

    return `Fixed delivery fee: ₱${Number(pricing?.fixed_fee || 0).toFixed(2)}.`;
}

function updateDeliveryFeeVisibility() {
    const deliverySelected =
        isDeliveryServiceSelected();

    deliveryFeeGroup?.classList.toggle(
        "hidden",
        !deliverySelected
    );

    if (!deliverySelected) {
        if (deliveryFeeInput) {
            deliveryFeeInput.value = "0.00";
        }

        clearDeliveryPricingError();
        return;
    }

    updateDeliveryPricingFields();
}

function populateBusinessHours(hours) {
    if (
        !hours ||
        typeof hours !== "object"
    ) {
        return;
    }

    DAYS.forEach((day) => {
        const row =
            document.querySelector(
                `.hours-row[data-day="${day}"]`
            );

        if (!row) {
            return;
        }

        const schedule =
            hours[day];

        if (!schedule) {
            return;
        }

        const openInput =
            row.querySelector(
                ".hours-open"
            );

        const closeInput =
            row.querySelector(
                ".hours-close"
            );

        const closedInput =
            row.querySelector(
                ".hours-closed"
            );

        const isClosed =
            Boolean(schedule.closed);

        closedInput.checked =
            isClosed;

        if (
            typeof schedule.open ===
                "string" &&
            schedule.open !== ""
        ) {
            openInput.value =
                schedule.open;
        }

        if (
            typeof schedule.close ===
                "string" &&
            schedule.close !== ""
        ) {
            closeInput.value =
                schedule.close;
        }

        openInput.disabled =
            isClosed;

        closeInput.disabled =
            isClosed;
    });
}

function populateDeliveryOptions(options) {
    let selectedOptions =
        Array.isArray(options)
            ? options
            : [];

    // Backward compatibility for drafts saved with the old
    // onboarding service names. Third-party FoodConnect
    // delivery is intentionally not carried forward.
    selectedOptions = selectedOptions
        .map((option) => {
            if (option === "pickup") {
                return "takeout";
            }

            if (option === "restaurant_delivery") {
                return "delivery";
            }

            return option;
        })
        .filter((option) =>
            ["dine-in", "takeout", "delivery"].includes(option)
        );

    deliveryOptionInputs.forEach(
        (checkbox) => {
            checkbox.checked =
                selectedOptions.includes(
                    checkbox.value
                );
        }
    );

    if (selectedOptions.length === 0) {
        const takeoutCheckbox =
            deliveryOptionInputs.find(
                (checkbox) =>
                    checkbox.value === "takeout"
            );

        if (takeoutCheckbox) {
            takeoutCheckbox.checked =
                true;
        }
    }
}

function renderApplicationStatus(
  status,
  rejectionReason = ""
) {
  statusBanner.className =
    "status-banner";

  if (status === "email_pending") {
    statusBanner.classList.add(
      "status-draft"
    );

    statusBanner.innerHTML = `
      <strong>
        Restaurant setup in progress
      </strong>

      <br>

      Your setup progress can be saved while email verification is pending.
      Verify your owner email before completing setup.
    `;

    statusBanner.classList.remove(
      "hidden"
    );

    return;
  }

  if (status === "submitted") {
    statusBanner.classList.add(
      "status-submitted"
    );

    statusBanner.innerHTML = `
      <strong>
        Application under review
      </strong>

      <br>

      Your restaurant application has been submitted.
      You cannot edit it while an administrator
      is reviewing it.
    `;

    statusBanner.classList.remove(
      "hidden"
    );

    return;
  }

  if (status === "needs_changes") {
    statusBanner.classList.add(
      "status-rejected"
    );

    statusBanner.innerHTML = `
      <strong>
        Changes requested
      </strong>

      <br>

      ${escapeHtml(
        rejectionReason ||
        "The administrator requested changes before your application can be approved."
      )}

      <br><br>

      Update the required information and submit
      your application again for review.
    `;

    statusBanner.classList.remove(
      "hidden"
    );

    return;
  }

  if (status === "rejected") {
    statusBanner.classList.add(
      "status-rejected"
    );

    statusBanner.innerHTML = `
      <strong>
        Application rejected
      </strong>

      <br>

      ${escapeHtml(
        rejectionReason ||
        "This restaurant application was permanently rejected."
      )}

      <br><br>

      This application can no longer be edited
      or resubmitted.
    `;

    statusBanner.classList.remove(
      "hidden"
    );

    return;
  }

  if (status === "approved") {
    statusBanner.classList.add(
      "status-submitted"
    );

    statusBanner.innerHTML = `
      <strong>
        Application approved
      </strong>

      <br>

      Your restaurant application has been approved.
    `;

    statusBanner.classList.remove(
      "hidden"
    );

    return;
  }

  statusBanner.classList.add(
    "status-draft"
  );

  statusBanner.innerHTML = `
    <strong>
      Draft application
    </strong>

    <br>

    Your restaurant is not yet visible to customers.
    Complete the setup and submit it for review.
  `;

  statusBanner.classList.remove(
    "hidden"
  );
}

function applyStatusRestrictions(status) {
  const isReadOnly =
    status === "submitted" ||
    status === "approved" ||
    status === "rejected";

    restaurantForm
        .querySelectorAll(
            "input, textarea"
        )
        .forEach((control) => {
            control.disabled =
                isReadOnly;
        });

        removeLogoButton.disabled =
    isReadOnly;

document
    .querySelector(
        ".logo-select-button"
    )
    ?.classList.toggle(
        "disabled",
        isReadOnly
    );

    applyMondayButton.disabled =
        isReadOnly;

    reviewEditButtons.forEach(
        (button) => {
            button.disabled =
                isReadOnly;
        }
    );

    if (isReadOnly) {
        confirmationCheckbox
            .closest(".confirmation-check")
            ?.classList.add("hidden");

        document
            .querySelector(".review-notice")
            ?.classList.add("hidden");

        confirmationError.classList.add(
            "hidden"
        );

        submittedState.classList.remove(
            "hidden"
        );

        restaurantForm
            .querySelector(".form-actions")
            ?.classList.add("hidden");

        return;
    }

    confirmationCheckbox
        .closest(".confirmation-check")
        ?.classList.remove("hidden");

    document
        .querySelector(".review-notice")
        ?.classList.remove("hidden");

    confirmationError.classList.remove(
        "hidden"
    );

    submittedState.classList.add(
        "hidden"
    );

    restaurantForm
        .querySelector(".form-actions")
        ?.classList.remove("hidden");
}

function showForm() {
    loadingState.classList.add(
        "hidden"
    );

    restaurantForm.classList.remove(
        "hidden"
    );

    wizardStatus.classList.remove(
        "hidden"
    );

if (
  currentApplicationStatus ===
    "submitted" ||
  currentApplicationStatus ===
    "approved" ||
  currentApplicationStatus ===
    "rejected"
) {
  currentStep = 5;
}

    showWizardStep(
        currentStep,
        false
    );
}

/* =========================================================
   WIZARD NAVIGATION
   ========================================================= */

function showWizardStep(
    step,
    shouldScroll = true
) {
    currentStep =
        Math.min(
            TOTAL_STEPS,
            Math.max(1, step)
        );

    wizardSteps.forEach((section) => {
        const sectionStep =
            Number(
                section.dataset.step
            );

        section.classList.toggle(
            "active",
            sectionStep === currentStep
        );
    });

    progressItems.forEach((item) => {
        const itemStep =
            Number(
                item.dataset.progressStep
            );

        item.classList.toggle(
            "active",
            itemStep === currentStep
        );

        item.classList.toggle(
            "completed",
            itemStep < currentStep
        );
    });

    wizardStepLabel.textContent =
        `Step ${currentStep} of ${TOTAL_STEPS}`;

    wizardStepTitle.textContent =
        STEP_TITLES[currentStep] ||
        "Restaurant setup";

    wizardProgressBar.style.width =
        `${(
            currentStep /
            TOTAL_STEPS
        ) * 100}%`;

    if (currentStep === 5) {
        renderReviewSummary();
    }

    updateWizardButtons();

    if (shouldScroll) {
        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });
    }
}

function handleNextStep() {
    if (
        isSubmitting ||
        nextButton.disabled
    ) {
        return;
    }

    clearValidationErrors();

    if (
        !validateCurrentStep(
            true
        )
    ) {
        updateWizardButtons();
        focusFirstInvalidField();

        showToast(
            "Check this step",
            "Complete all required information before continuing.",
            "error"
        );

        return;
    }

    showWizardStep(
        currentStep + 1
    );
}

function handlePreviousStep() {
    if (
        isSubmitting ||
        currentStep <= 1
    ) {
        return;
    }

    clearValidationErrors();

    showWizardStep(
        currentStep - 1
    );
}

function handleReviewEdit(event) {
    const button =
        event.currentTarget;

    const step =
        Number(
            button.dataset.editStep
        );

    if (
        !Number.isInteger(step) ||
        step < 1 ||
        step >= TOTAL_STEPS
    ) {
        return;
    }

    showWizardStep(step);
}

function updateWizardButtons() {
  const isReadOnly =
    currentApplicationStatus ===
      "submitted" ||
    currentApplicationStatus ===
      "approved" ||
    currentApplicationStatus ===
      "rejected";

    backButton.classList.toggle(
        "hidden",
        currentStep === 1 ||
        isReadOnly
    );

    nextButton.classList.toggle(
        "hidden",
        currentStep === TOTAL_STEPS ||
        isReadOnly
    );

    submitButton.classList.toggle(
        "hidden",
        currentStep !== TOTAL_STEPS ||
        isReadOnly
    );

    saveDraftButton.classList.toggle(
        "hidden",
        isReadOnly
    );

    if (!isReadOnly) {
        nextButton.disabled =
            currentStep < TOTAL_STEPS
                ? !validateCurrentStep(false)
                : true;

        const formReadyForSubmission =
            currentStep === TOTAL_STEPS
                ? validateFormForSubmission(
                    false
                )
                : false;

        submitButton.disabled =
            currentStep !== TOTAL_STEPS ||
            !partnerVerificationLoaded ||
            !ownerEmailVerified ||
            !formReadyForSubmission;

        if (
            currentStep === TOTAL_STEPS &&
            !ownerEmailVerified
        ) {
            submitButton.textContent =
                partnerVerificationLoaded
                    ? "Verify email to complete setup"
                    : "Checking email verification...";

            submitButton.title =
                "Email verification is required before completing restaurant setup.";
        } else {
            submitButton.textContent =
                "Complete setup";

            submitButton.removeAttribute(
                "title"
            );
        }
    }
}

/* =========================================================
   STEP VALIDATION
   ========================================================= */

function validateCurrentStep(
    showErrors = true
) {
    switch (currentStep) {
        case 1:
            return validateRestaurantDetailsStep(
                showErrors
            );

        case 2:
            return validateLocationStep(
                showErrors
            );

        case 3:
            return validateBusinessHours(
                showErrors
            );

        case 4:
            return validateOrderServicesStep(
                showErrors
            );

        case 5:
            return validateConfirmationStep(
                showErrors
            );

        default:
            return false;
    }
}

function validateRestaurantDetailsStep(
    showErrors = true
) {
    let valid = true;

    valid =
        validateRequiredField(
            restaurantNameInput,
            "Restaurant name is required.",
            showErrors
        ) && valid;

    valid =
        validateRequiredField(
            cuisineInput,
            "Restaurant type or cuisine is required.",
            showErrors
        ) && valid;

    valid =
        validateRequiredField(
            restaurantContactInput,
            "Business contact number is required.",
            showErrors
        ) && valid;

    if (
        restaurantContactInput.value.trim() !== "" &&
        !window.FoodConnectPhone.isValid(restaurantContactInput.value)
    ) {
        if (showErrors) {
            setFieldError(
                restaurantContactInput,
                "Enter a valid Philippine mobile number after +63, starting with 9."
            );
        }
        valid = false;
    }

    valid =
        validateRequiredField(
            businessEmailInput,
            "Business email is required.",
            showErrors
        ) && valid;

    if (
        businessEmailInput.value.trim() !== "" &&
        !businessEmailInput.validity.valid
    ) {
        if (showErrors) {
            setFieldError(
                businessEmailInput,
                "Enter a valid email address."
            );
        }

        valid = false;
    }

    /*
     * Verification documents are now part of Step 1.
     * The owner cannot continue until all three required
     * documents have been uploaded successfully.
     */
    if (
        window.FoodConnectVerificationDocuments &&
        typeof window
            .FoodConnectVerificationDocuments
            .validateForSubmit === "function"
    ) {
        valid =
            window
                .FoodConnectVerificationDocuments
                .validateForSubmit(showErrors) &&
            valid;
    } else {
        /*
         * Fail closed if the verification controller did not load.
         * This prevents bypassing the requirement because of a
         * missing/failed script.
         */
        valid = false;

        if (showErrors) {
            const verificationError =
                document.getElementById(
                    "verificationDocumentsError"
                );

            if (verificationError) {
                verificationError.textContent =
                    "Restaurant verification documents are required before continuing.";
            }
        }
    }

    return valid;
}

function validateLocationStep(
    showErrors = true
) {
    let valid = true;

    valid =
        validateRequiredField(
            restaurantAddressInput,
            "Street address is required.",
            showErrors
        ) && valid;

    valid =
        validateRequiredField(
            provinceInput,
            "Province is required.",
            showErrors
        ) && valid;

    valid =
        validateRequiredField(
            cityMunicipalityInput,
            "City or municipality is required.",
            showErrors
        ) && valid;

    valid =
        validateRequiredField(
            barangayInput,
            "Barangay is required.",
            showErrors
        ) && valid;

    if (
        postalCodeInput.value.trim() !== "" &&
        !/^[0-9]{4,10}$/.test(
            postalCodeInput.value.trim()
        )
    ) {
        if (showErrors) {
            setFieldError(
                postalCodeInput,
                "Postal code must contain 4 to 10 digits."
            );
        }

        valid = false;
    }

    return valid;
}

function validateBusinessHours(
    showErrors = true
) {
    let valid = true;
    let firstErrorMessage = "";

    if (showErrors) {
        clearBusinessHoursError();
    }

    document
        .querySelectorAll(".hours-row")
        .forEach((row) => {
            const day =
                row.dataset.day || "";

            const closedInput =
                row.querySelector(
                    ".hours-closed"
                );

            const openInput =
                row.querySelector(
                    ".hours-open"
                );

            const closeInput =
                row.querySelector(
                    ".hours-close"
                );

            const isClosed =
                closedInput.checked;

            if (showErrors) {
                row.classList.remove(
                    "invalid-row"
                );

                openInput.classList.remove(
                    "invalid"
                );

                closeInput.classList.remove(
                    "invalid"
                );
            }

            if (isClosed) {
                return;
            }

            if (
                openInput.value === "" ||
                closeInput.value === ""
            ) {
                valid = false;

                if (
                    firstErrorMessage === ""
                ) {
                    firstErrorMessage =
                        `Enter opening and closing times for ${day}.`;
                }

                if (showErrors) {
                    row.classList.add(
                        "invalid-row"
                    );

                    if (
                        openInput.value === ""
                    ) {
                        openInput.classList.add(
                            "invalid"
                        );
                    }

                    if (
                        closeInput.value === ""
                    ) {
                        closeInput.classList.add(
                            "invalid"
                        );
                    }
                }

                return;
            }

            if (
                openInput.value ===
                closeInput.value
            ) {
                valid = false;

                if (
                    firstErrorMessage === ""
                ) {
                    firstErrorMessage =
                        `${day}'s opening and closing times cannot be the same.`;
                }

                if (showErrors) {
                    row.classList.add(
                        "invalid-row"
                    );

                    openInput.classList.add(
                        "invalid"
                    );

                    closeInput.classList.add(
                        "invalid"
                    );
                }
            }
        });

    if (
        !valid &&
        showErrors
    ) {
        businessHoursContainer.classList.add(
            "invalid-section"
        );

        businessHoursError.textContent =
            firstErrorMessage ||
            "Enter valid business hours.";
    }

    return valid;
}

function validateOrderServicesStep(
    showErrors = true
) {
    const selectedOptions =
        deliveryOptionInputs.filter(
            (checkbox) =>
                checkbox.checked
        );

    const servicesValid =
        selectedOptions.length > 0;

    if (showErrors) {
        if (servicesValid) {
            clearDeliveryOptionsError();
        } else {
            deliveryOptionsError.textContent =
                "Select at least one order type.";

            document
                .querySelector(
                    ".service-options"
                )
                ?.classList.add(
                    "invalid-section"
                );
        }
    }

    const pricingValid =
        servicesValid
            ? validateDeliveryPricing(
                showErrors
            )
            : true;

    return servicesValid && pricingValid;
}

function validateConfirmationStep(
    showErrors = true
) {
    const valid =
        confirmationCheckbox.checked;

    if (showErrors) {
        if (valid) {
            clearConfirmationError();
        } else {
            confirmationError.textContent =
                "You must confirm that the information is complete and accurate.";

            confirmationCheckbox
                .closest(
                    ".confirmation-check"
                )
                ?.classList.add(
                    "invalid-confirmation"
                );
        }
    }

    return valid;
}

function validateRequiredInformation(
    showErrors = true
) {
    let valid = true;

    valid =
        validateRestaurantDetailsStep(
            showErrors
        ) && valid;

    valid =
        validateLocationStep(
            showErrors
        ) && valid;

    return valid;
}

function validateFormForSubmission(
    showErrors = true
) {
    let valid = true;

    valid =
        validateRequiredInformation(
            showErrors
        ) && valid;

    valid =
        validateBusinessHours(
            showErrors
        ) && valid;

    valid =
        validateOrderServicesStep(
            showErrors
        ) && valid;

    valid =
        validateConfirmationStep(
            showErrors
        ) && valid;

    return valid;
}

/* =========================================================
   SAVE AND SUBMIT
   ========================================================= */

async function handleSaveDraft() {
    if (isSubmitting) {
        return;
    }

    clearValidationErrors();

    const valid =
        validateRequiredInformation(
            true
        );

    if (!valid) {
        openFirstInvalidStep();

        showToast(
            "Missing information",
            "Complete all required restaurant and location fields before saving.",
            "error"
        );

        focusFirstInvalidField();
        return;
    }

    const payload =
        collectFormData("save");

    await saveApplication(
        payload,
        "save"
    );
}

async function handleSubmitApplication(
    event
) {
    event.preventDefault();

   if (
  isSubmitting ||
  currentApplicationStatus ===
    "submitted" ||
  currentApplicationStatus ===
    "approved" ||
  currentApplicationStatus ===
    "rejected"
) {
  return;
}

    if (
        !partnerVerificationLoaded ||
        !ownerEmailVerified
    ) {
        partnerEmailVerificationBanner
            ?.scrollIntoView({
                behavior: "smooth",
                block: "center"
            });

        showToast(
            "Email verification required",
            partnerVerificationLoaded
                ? "Request or complete owner email verification before completing restaurant setup. Your saved setup progress is safe."
                : "FoodConnect must confirm your email verification status before completing setup.",
            "error"
        );

        return;
    }

    clearValidationErrors();

    const valid =
        validateFormForSubmission(
            true
        );

    if (!valid) {
        openFirstInvalidStep();

        showToast(
            "Check your application",
            "Complete every required field before submitting.",
            "error"
        );

        focusFirstInvalidField();
        updateWizardButtons();

        return;
    }

    const payload =
        collectFormData("submit");

    await saveApplication(
        payload,
        "submit"
    );
}

async function saveApplication(
    payload,
    action
) {
    setSubmittingState(
        true,
        action
    );

    try {
        const response =
            await fetch(
                API.saveApplication,
                {
                    method: "POST",
                    credentials: "include",

                    headers: {
                        "Content-Type":
                            "application/json",

                        "Accept":
                            "application/json"
                    },

                    body:
                        JSON.stringify(
                            payload
                        )
                }
            );

        const result =
            await parseJsonResponse(
                response
            );

        if (response.status === 401) {
            window.location.href =
                "/?open=partner-portal";

            return false;
        }

        if (
            !response.ok ||
            !result.success
        ) {
            if (result.verification_required === true) {
                await loadPartnerVerificationStatus(
                    true
                );

                partnerEmailVerificationBanner
                    ?.scrollIntoView({
                        behavior: "smooth",
                        block: "center"
                    });
            }

            if (
                response.status === 422 &&
                result.errors
            ) {
                applyServerValidationErrors(
                    result.errors
                );
            }

            throw new Error(
                result.message ||
                "Changes could not be saved the restaurant application."
            );
        }

        currentApplicationStatus =
            result.status ||
            (
                action === "submit"
                    ? "submitted"
                    : "draft"
            );

       if (action === "submit") {
    currentApplicationStatus =
        "setup_completed";

    showToast(
        "Setup completed",
        result.message ||
        "Your private restaurant has been created successfully.",
        "success"
    );

    window.setTimeout(() => {
        window.location.href =
            "/frontend/html/owner_dashboard.html";
    }, 1200);

    return true;
}

        renderApplicationStatus(
            currentApplicationStatus
        );

        showToast(
            "Draft saved",
            result.message ||
            "Restaurant setup draft saved successfully.",
            "success"
        );

        return true;
    } catch (error) {
        console.error(
            "Restaurant application save error:",
            error
        );

        showToast(
            "Changes could not be saved",
            error.message,
            "error"
        );

        return false;
    } finally {
        setSubmittingState(
            false,
            action
        );
    }
}

/* =========================================================
   REVIEW SUMMARY
   ========================================================= */

   async function handleRestaurantLogoChange(
    event
) {
    const file =
        event.target.files[0];

    restaurantLogoError.textContent =
        "";

    if (!file) {
        return;
    }

    const allowedTypes = [
        "image/jpeg",
        "image/png",
        "image/webp"
    ];

    const maximumFileSize =
        2 * 1024 * 1024;

    if (
        !allowedTypes.includes(
            file.type
        )
    ) {
        restaurantLogoInput.value =
            "";

        restaurantLogoError.textContent =
            "Only JPG, PNG, and WEBP files are allowed.";

        return;
    }

    if (
        file.size >
        maximumFileSize
    ) {
        restaurantLogoInput.value =
            "";

        restaurantLogoError.textContent =
            "The restaurant logo must not exceed 2 MB.";

        return;
    }

    const temporaryPreviewUrl =
        URL.createObjectURL(
            file
        );

    renderRestaurantLogoUrl(
        temporaryPreviewUrl
    );

    const formData =
        new FormData();

    formData.append(
        "restaurant_logo",
        file
    );

    restaurantLogoInput.disabled =
        true;

    try {
        const response =
            await fetch(
                API.uploadRestaurantLogo,
                {
                    method: "POST",
                    credentials:
                        "same-origin",
                    body:
                        formData
                }
            );

        const result =
            await parseJsonResponse(
                response
            );

        if (
            !response.ok ||
            result.success !== true
        ) {
            throw new Error(
                result.message ||
                "Unable to upload the restaurant logo."
            );
        }

        restaurantLogoPathInput.value =
            result.logo_path || "";

        renderRestaurantLogo(
            result.logo_path || ""
        );

        showToast(
            "Logo uploaded",
            result.message ||
            "Restaurant logo uploaded successfully.",
            "success"
        );
    } catch (error) {
        restaurantLogoPathInput.value =
            "";

        renderRestaurantLogo(
            ""
        );

        restaurantLogoError.textContent =
            error.message;

        showToast(
            "Upload failed",
            error.message,
            "error"
        );
    } finally {
        restaurantLogoInput.disabled =
            false;

        restaurantLogoInput.value =
            "";

        URL.revokeObjectURL(
            temporaryPreviewUrl
        );
    }
}

function removeRestaurantLogo() {
    restaurantLogoPathInput.value =
        "";

    restaurantLogoInput.value =
        "";

    restaurantLogoError.textContent =
        "";

    renderRestaurantLogo(
        ""
    );
}

function renderRestaurantLogo(
    logoPath
) {
    const cleanedPath =
        String(
            logoPath || ""
        ).trim();

    if (cleanedPath === "") {
        renderRestaurantLogoUrl(
            ""
        );

        return;
    }

    const logoUrl =
        cleanedPath.startsWith(
            "http://"
        ) ||
        cleanedPath.startsWith(
            "https://"
        ) ||
        cleanedPath.startsWith(
            "/"
        )
            ? cleanedPath
            : `/${cleanedPath}`;

    renderRestaurantLogoUrl(
        logoUrl
    );
}

function renderRestaurantLogoUrl(
    logoUrl
) {
    const hasLogo =
        String(
            logoUrl || ""
        ).trim() !== "";

    logoPreviewImage.src =
        hasLogo
            ? logoUrl
            : "";

    logoPreviewImage.classList.toggle(
        "hidden",
        !hasLogo
    );

    logoPreviewPlaceholder.classList.toggle(
        "hidden",
        hasLogo
    );

    removeLogoButton.classList.toggle(
        "hidden",
        !hasLogo
    );
}

function renderReviewLogo(
    logoPath
) {
    const cleanedPath =
        String(
            logoPath || ""
        ).trim();

    const hasLogo =
        cleanedPath !== "";

    const logoUrl =
        hasLogo
            ? (
                cleanedPath.startsWith(
                    "http://"
                ) ||
                cleanedPath.startsWith(
                    "https://"
                ) ||
                cleanedPath.startsWith(
                    "/"
                )
                    ? cleanedPath
                    : `/${cleanedPath}`
            )
            : "";

    reviewLogoImage.src =
        logoUrl;

    reviewLogoImage.classList.toggle(
        "hidden",
        !hasLogo
    );

    reviewLogoPlaceholder.classList.toggle(
        "hidden",
        hasLogo
    );
}

function resolveRestaurantLogoUrl(
    logoPath
) {
    const cleanedPath =
        String(
            logoPath || ""
        ).trim();

    if (cleanedPath === "") {
        return "";
    }

    if (
        cleanedPath.startsWith(
            "http://"
        ) ||
        cleanedPath.startsWith(
            "https://"
        ) ||
        cleanedPath.startsWith(
            "/"
        )
    ) {
        return cleanedPath;
    }

    return `/${cleanedPath}`;
}

function formatPeso(
    value
) {
    const amount =
        normalizeMoneyValue(
            value
        );

    return `₱${amount.toFixed(2)}`;
}

function valueOrFallback(
    value,
    fallback
) {
    const cleanedValue =
        String(
            value || ""
        ).trim();

    return cleanedValue !== ""
        ? cleanedValue
        : fallback;
}

function renderReviewSummary() {
    const logoPath =
        restaurantLogoPathInput.value.trim();

    renderReviewLogo(
        logoPath
    );

    reviewRestaurantName.textContent =
        valueOrDash(
            restaurantNameInput.value
        );

    reviewCuisine.textContent =
        valueOrDash(
            cuisineInput.value
        );

    reviewRestaurantContact.textContent =
        window.FoodConnectPhone.format(
            restaurantContactInput.value,
            "—"
        );

    reviewBusinessEmail.textContent =
        valueOrDash(
            businessEmailInput.value
        );

    const addressParts = [
        restaurantAddressInput.value,
        barangayInput.value,
        cityMunicipalityInput.value,
        provinceInput.value,
        postalCodeInput.value
    ]
        .map((value) =>
            String(value).trim()
        )
        .filter((value) =>
            value !== ""
        );

    reviewAddress.textContent =
        addressParts.length > 0
            ? addressParts.join(", ")
            : "—";

    const hours =
        collectBusinessHours();

    reviewBusinessHours.innerHTML =
        DAYS.map((day) => {
            const schedule =
                hours[day];

            const scheduleText =
                schedule.closed
                    ? "Closed"
                    : `${formatTimeDisplay(
                        schedule.open
                    )} – ${formatTimeDisplay(
                        schedule.close
                    )}`;

            return `
                <div class="review-hour-item">
                    <strong>
                        ${escapeHtml(day)}
                    </strong>

                    <span>
                        ${escapeHtml(scheduleText)}
                    </span>
                </div>
            `;
        }).join("");

    const selectedOptions =
        deliveryOptionInputs
            .filter(
                (checkbox) =>
                    checkbox.checked
            )
            .map(
                (checkbox) =>
                    checkbox.value
            );

    reviewDeliveryOptions.innerHTML =
        selectedOptions.length > 0
            ? selectedOptions
                .map((option) => {
                    const label =
                        DELIVERY_OPTION_LABELS[
                            option
                        ] || option;

                    return `
                        <span class="review-service-tag">
                            ${escapeHtml(label)}
                        </span>
                    `;
                })
                .join("")
            : `
                <span class="review-service-tag">
                    No service selected
                </span>
            `;

    if (reviewDeliveryPricing) {
        const deliverySelected =
            selectedOptions.includes(
                "delivery"
            );

        reviewDeliveryPricing.hidden =
            !deliverySelected;

        reviewDeliveryPricing.textContent =
            deliverySelected
                ? formatDeliveryPricingSummary(
                    collectDeliveryPricing()
                )
                : "";
    }
}

/* =========================================================
   COLLECT FORM DATA
   ========================================================= */

function collectFormData(action) {
    const selectedDeliveryOptions =
        deliveryOptionInputs
            .filter(
                (checkbox) =>
                    checkbox.checked
            )
            .map(
                (checkbox) =>
                    checkbox.value
            );

    const deliveryPricing =
        collectDeliveryPricing();

    return {
        action,

        logo_path:
    restaurantLogoPathInput.value.trim(),

        restaurant_name:
            restaurantNameInput.value.trim(),

        cuisine:
            cuisineInput.value.trim(),

        restaurant_contact:
            window.FoodConnectPhone.normalize(restaurantContactInput.value),

        business_email:
            businessEmailInput.value.trim(),

        restaurant_description:
            restaurantDescriptionInput.value.trim(),

        restaurant_address:
            restaurantAddressInput.value.trim(),

        province:
            provinceInput.value.trim(),

        city_municipality:
            cityMunicipalityInput.value.trim(),

        barangay:
            barangayInput.value.trim(),

        postal_code:
            postalCodeInput.value.trim(),

        business_hours:
            collectBusinessHours(),

        delivery_options:
            selectedDeliveryOptions,

        delivery_pricing_type:
            selectedDeliveryOptions.includes("delivery")
                ? deliveryPricing.pricing_type
                : "fixed",

        delivery_pricing:
            selectedDeliveryOptions.includes("delivery")
                ? deliveryPricing
                : {
                    pricing_type: "fixed",
                    fixed_fee: 0
                },

        /*
         * Legacy compatibility value. The server remains authoritative
         * and stores the complete delivery-pricing policy separately.
         */
        delivery_fee:
            selectedDeliveryOptions.includes("delivery")
                ? getLegacyDeliveryFeeFromPricing(
                    deliveryPricing
                )
                : 0
    };
}

function collectBusinessHours() {
    const hours = {};

    document
        .querySelectorAll(".hours-row")
        .forEach((row) => {
            const day =
                row.dataset.day;

            const closed =
                row.querySelector(
                    ".hours-closed"
                ).checked;

            const open =
                row.querySelector(
                    ".hours-open"
                ).value;

            const close =
                row.querySelector(
                    ".hours-close"
                ).value;

            hours[day] = {
                closed,

                open:
                    closed
                        ? null
                        : open,

                close:
                    closed
                        ? null
                        : close
            };
        });

    return hours;
}

/* =========================================================
   VALIDATION ERROR HELPERS
   ========================================================= */

function validateRequiredField(
    field,
    message,
    showErrors = true
) {
    const valid =
        field.value.trim() !== "";

    if (
        !valid &&
        showErrors
    ) {
        setFieldError(
            field,
            message
        );
    }

    return valid;
}

function setFieldError(
    field,
    message
) {
    field.classList.add(
        "invalid"
    );

    const group =
        field.closest(
            ".form-group"
        );

    if (!group) {
        return;
    }

    const errorElement =
        group.querySelector(
            ".field-error"
        );

    if (errorElement) {
        errorElement.textContent =
            message;
    }
}

function clearFieldError(field) {
    field.classList.remove(
        "invalid"
    );

    const group =
        field.closest(
            ".form-group"
        );

    const errorElement =
        group?.querySelector(
            ".field-error"
        );

    if (errorElement) {
        errorElement.textContent = "";
    }
}

function clearBusinessHoursError() {
    businessHoursError.textContent = "";

    businessHoursContainer.classList.remove(
        "invalid-section"
    );

    document
        .querySelectorAll(".hours-row")
        .forEach((row) => {
            row.classList.remove(
                "invalid-row"
            );
        });

    document
        .querySelectorAll(
            ".hours-open, .hours-close"
        )
        .forEach((input) => {
            input.classList.remove(
                "invalid"
            );
        });
}

function clearDeliveryOptionsError() {
    deliveryOptionsError.textContent = "";

    document
        .querySelector(
            ".service-options"
        )
        ?.classList.remove(
            "invalid-section"
        );
}

function clearConfirmationError() {
    confirmationError.textContent = "";

    confirmationCheckbox
        .closest(
            ".confirmation-check"
        )
        ?.classList.remove(
            "invalid-confirmation"
        );
}

function clearValidationErrors() {
    document
        .querySelectorAll(
            ".invalid"
        )
        .forEach((field) => {
            field.classList.remove(
                "invalid"
            );
        });

    document
        .querySelectorAll(
            ".field-error"
        )
        .forEach((errorElement) => {
            errorElement.textContent = "";
        });

    clearBusinessHoursError();
    clearDeliveryOptionsError();
    clearConfirmationError();
}

function openFirstInvalidStep() {
    const invalidField =
        document.querySelector(
            ".form-group .invalid"
        );

    if (invalidField) {
        const section =
            invalidField.closest(
                ".wizard-step"
            );

        const step =
            Number(
                section?.dataset.step
            );

        if (
            Number.isInteger(step)
        ) {
            showWizardStep(
                step,
                false
            );

            return;
        }
    }

    if (
        businessHoursContainer.classList.contains(
            "invalid-section"
        )
    ) {
        showWizardStep(
            3,
            false
        );

        return;
    }

    if (
        document
            .querySelector(
                ".service-options"
            )
            ?.classList.contains(
                "invalid-section"
            )
    ) {
        showWizardStep(
            4,
            false
        );

        return;
    }

    if (
        confirmationCheckbox
            .closest(
                ".confirmation-check"
            )
            ?.classList.contains(
                "invalid-confirmation"
            )
    ) {
        showWizardStep(
            5,
            false
        );
    }
}

function focusFirstInvalidField() {
    const invalidField =
        document.querySelector(
            ".form-group .invalid"
        );

    if (invalidField) {
        invalidField.focus();

        invalidField.scrollIntoView({
            behavior: "smooth",
            block: "center"
        });

        return;
    }

    const invalidHoursInput =
        document.querySelector(
            ".hours-input.invalid"
        );

    if (invalidHoursInput) {
        invalidHoursInput.focus();

        invalidHoursInput.scrollIntoView({
            behavior: "smooth",
            block: "center"
        });

        return;
    }

    if (
        document
            .querySelector(
                ".service-options"
            )
            ?.classList.contains(
                "invalid-section"
            )
    ) {
        deliveryOptionInputs[0]?.focus();

        document
            .querySelector(
                ".service-options"
            )
            ?.scrollIntoView({
                behavior: "smooth",
                block: "center"
            });

        return;
    }

    if (
        confirmationCheckbox
            .closest(
                ".confirmation-check"
            )
            ?.classList.contains(
                "invalid-confirmation"
            )
    ) {
        confirmationCheckbox.focus();
    }
}

function applyServerValidationErrors(
    errors
) {
    if (
        !errors ||
        typeof errors !== "object"
    ) {
        return;
    }

    const fieldMap = {
        restaurant_name:
            restaurantNameInput,

        cuisine:
            cuisineInput,

        restaurant_contact:
            restaurantContactInput,

        business_email:
            businessEmailInput,

        restaurant_address:
            restaurantAddressInput,

        province:
            provinceInput,

        city_municipality:
            cityMunicipalityInput,

        barangay:
            barangayInput,

        postal_code:
            postalCodeInput
    };

    Object.entries(errors).forEach(
        ([fieldName, message]) => {
            if (
                fieldName ===
                "business_hours"
            ) {
                businessHoursError.textContent =
                    String(message);

                businessHoursContainer.classList.add(
                    "invalid-section"
                );

                return;
            }

            if (
                fieldName ===
                "delivery_options"
            ) {
                deliveryOptionsError.textContent =
                    String(message);

                document
                    .querySelector(
                        ".service-options"
                    )
                    ?.classList.add(
                        "invalid-section"
                    );

                return;
            }

            const field =
                fieldMap[fieldName];

            if (field) {
                setFieldError(
                    field,
                    String(message)
                );
            }
        }
    );

    openFirstInvalidStep();
    focusFirstInvalidField();
}

/* =========================================================
   SUBMITTING STATE
   ========================================================= */

function setSubmittingState(
    submitting,
    action
) {
    isSubmitting =
        submitting;

    saveDraftButton.disabled =
        submitting;

    nextButton.disabled =
        submitting;

    backButton.disabled =
        submitting;

    submitButton.disabled =
        submitting;

    logoutButton.disabled =
        submitting;

        if (openCustomerPagePreview) {
    openCustomerPagePreview.disabled =
        submitting;
}

    if (submitting) {
        if (action === "submit") {
            submitButton.textContent =
            "Completing setup...";
        } else {
            saveDraftButton.textContent =
                "Saving...";
        }

        return;
    }

    saveDraftButton.textContent =
        "Save as draft";

    submitButton.textContent =
    "Complete setup";

    if (
        currentApplicationStatus ===
        "submitted"
    ) {
        applyStatusRestrictions(
            "submitted"
        );

        return;
    }

    updateWizardButtons();
}

/* =========================================================
   LOGOUT
   ========================================================= */

async function handleLogout() {
    logoutButton.disabled =
        true;

    try {
        await fetch(
            API.logout,
            {
                method: "POST",
                credentials: "include",

                headers: {
                    "Accept":
                        "application/json"
                }
            }
        );
    } catch (error) {
        console.error(
            "Logout error:",
            error
        );
    } finally {
        window.location.href =
            "/?open=partner-portal";
    }
}

/* =========================================================
   HELPERS
   ========================================================= */

function redirectApprovedOwner(
    restaurant
) {
    const businessStatus =
        String(
            restaurant?.business_status ||
            ""
        ).toLowerCase();

    if (
        businessStatus === "approved" ||
        businessStatus === "active"
    ) {
        window.location.href =
"/frontend/html/owner_dashboard.html"
        return;
    }

    showToast(
        "Restaurant record found",
        "Your restaurant already exists and is awaiting activation.",
        "success"
    );

    window.setTimeout(() => {
        window.location.href =
"/frontend/html/owner_dashboard.html"    }, 1200);
}

function updateDescriptionCounter() {
    const length =
        restaurantDescriptionInput
            .value
            .length;

    descriptionCounter.textContent =
        `${length} / 1000`;
}

function showToast(
    title,
    message,
    type = "success"
) {
    const toast =
        document.createElement(
            "div"
        );

    toast.className =
        `toast ${type}`;

    toast.innerHTML = `
        <strong>
            ${escapeHtml(title)}
        </strong>

        <p>
            ${escapeHtml(message)}
        </p>
    `;

    toastContainer.appendChild(
        toast
    );

    window.setTimeout(() => {
        toast.remove();
    }, 4500);
}

async function parseJsonResponse(
    response
) {
    const responseText =
        await response.text();

    if (
        responseText.trim() === ""
    ) {
        return {};
    }

    try {
        return JSON.parse(
            responseText
        );
    } catch (error) {
        console.error(
            "Invalid JSON response:",
            responseText
        );

        throw new Error(
            "Something went wrong. Please try again."
        );
    }
}

function normalizeMoneyValue(
    value
) {
    const number =
        Number.parseFloat(value);

    if (
        !Number.isFinite(number) ||
        number < 0
    ) {
        return 0;
    }

    return Number(
        number.toFixed(2)
    );
}

function formatMoneyInput(
    value
) {
    const number =
        Number.parseFloat(value);

    if (
        !Number.isFinite(number)
    ) {
        return "0.00";
    }

    return Math.max(
        0,
        number
    ).toFixed(2);
}

function formatTimeDisplay(
    time
) {
    if (
        typeof time !== "string" ||
        !/^[0-2][0-9]:[0-5][0-9]$/.test(
            time
        )
    ) {
        return time || "—";
    }

    const [
        hoursText,
        minutes
    ] = time.split(":");

    const hours =
        Number(hoursText);

    const period =
        hours >= 12
            ? "PM"
            : "AM";

    const displayHours =
        hours % 12 === 0
            ? 12
            : hours % 12;

    return `${displayHours}:${minutes} ${period}`;
}

function valueOrDash(
    value
) {
    const cleaned =
        String(value).trim();

    return cleaned !== ""
        ? cleaned
        : "—";
}

function escapeHtml(
    value
) {
    return String(value)
        .replaceAll(
            "&",
            "&amp;"
        )
        .replaceAll(
            "<",
            "&lt;"
        )
        .replaceAll(
            ">",
            "&gt;"
        )
        .replaceAll(
            '"',
            "&quot;"
        )
        .replaceAll(
            "'",
            "&#039;"
        );
}