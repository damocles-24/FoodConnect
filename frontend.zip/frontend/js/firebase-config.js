import {
  initializeApp
} from "https://www.gstatic.com/firebasejs/12.17.0/firebase-app.js";

import {
  getDatabase
} from "https://www.gstatic.com/firebasejs/12.17.0/firebase-database.js";

import {
  getAuth,
  signInAnonymously,
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/12.17.0/firebase-auth.js";

/* =========================================================
   FIREBASE CONFIGURATION
========================================================= */

const firebaseConfig = {
  apiKey:
    "AIzaSyAUUxICI4qtj5XLY5mWDhtxPWtBLzK2Wq8",

  authDomain:
    "foodconnect-94d23.firebaseapp.com",

  databaseURL:
    "https://foodconnect-94d23-default-rtdb.asia-southeast1.firebasedatabase.app",

  projectId:
    "foodconnect-94d23",

  storageBucket:
    "foodconnect-94d23.firebasestorage.app",

  messagingSenderId:
    "61518539735",

  appId:
    "1:61518539735:web:1de91f46968cda0219f992",

  measurementId:
    "G-MZHEBHQHHH"
};

/* =========================================================
   INITIALIZE FIREBASE
========================================================= */

const firebaseApp =
  initializeApp(firebaseConfig);

const realtimeDatabase =
  getDatabase(firebaseApp);

const firebaseAuth =
  getAuth(firebaseApp);

/* =========================================================
   SHARED EXPORTS
========================================================= */

export {
  firebaseApp,
  realtimeDatabase,
  firebaseAuth,
  signInAnonymously,
  onAuthStateChanged
};