<?php

header(
    "Content-Type: application/json; charset=utf-8"
);

header(
    "Cache-Control: no-store, no-cache, must-revalidate, max-age=0"
);

require_once __DIR__ . "/db.php";
require_once __DIR__ . "/product_image_helper.php";
require_once __DIR__ . "/restaurant_availability_helper.php";

/*
 * Promotion dates are entered and stored
 * using Philippine local time.
 */
$promotionTimezone =
    new DateTimeZone(
        "Asia/Manila"
    );

/* =========================================================
   JSON RESPONSE
========================================================= */

function respond_json(
    array $data,
    int $statusCode = 200
): void {
    http_response_code($statusCode);

    echo json_encode(
        $data,
        JSON_UNESCAPED_UNICODE |
        JSON_UNESCAPED_SLASHES
    );

    exit;
}

/* =========================================================
   REQUEST METHOD
========================================================= */

if (
    strtoupper(
        (string) (
            $_SERVER["REQUEST_METHOD"] ?? ""
        )
    ) !== "GET"
) {
    respond_json([
        "success" => false,
        "message" => "This action is not available."
    ], 405);
}

/* =========================================================
   RESTAURANT ID
========================================================= */

$restaurant_id = filter_input(
    INPUT_GET,
    "restaurant_id",
    FILTER_VALIDATE_INT
);

if (
    $restaurant_id === false ||
    $restaurant_id === null ||
    $restaurant_id <= 0
) {
    respond_json([
        "success" => false,
        "message" => "Invalid restaurant ID."
    ], 422);
}

/* =========================================================
   VERIFY RESTAURANT
========================================================= */

$restaurantStmt = $conn->prepare("
    SELECT
        r.restaurant_id,
        r.name,
        r.opening_hours,
        r.business_status

    FROM tbl_restaurants AS r

    INNER JOIN tbl_users AS owner
        ON owner.user_id = r.owner_id
        AND owner.role = 'owner'
        AND owner.status = 1
        AND owner.is_verified = 1

    WHERE r.restaurant_id = ?
      AND r.setup_completed = 1
      AND r.customer_visibility = 'Visible'

    LIMIT 1
");

if (!$restaurantStmt) {
    error_log(
        "get_public_products.php restaurant prepare error: " .
        $conn->error
    );

    respond_json([
        "success" => false,
        "message" => "Unable to load the restaurant."
    ], 500);
}

$restaurantStmt->bind_param(
    "i",
    $restaurant_id
);

$restaurantStmt->execute();

$restaurant = $restaurantStmt
    ->get_result()
    ->fetch_assoc();

$restaurantStmt->close();

if (!$restaurant) {
    respond_json([
        "success" => false,
        "message" =>
            "This restaurant is currently unavailable on FoodConnect.",
        "products" => []
    ], 404);
}

$business_status = trim(
    (string) (
        $restaurant["business_status"] ??
        "Closed"
    )
);

$opening_hours =
    (string) (
        $restaurant["opening_hours"] ?? ""
    );

$availability =
    fc_restaurant_evaluate_availability(
        $business_status,
        $opening_hours
    );

$is_accepting_orders =
    (bool) $availability["is_accepting_orders"];

/* =========================================================
   LOAD PUBLIC PRODUCTS
========================================================= */

$stmt = $conn->prepare("
    SELECT
        product_id,
        product_name,
        category,
        description,
        item_type,
        size,
        price,
        stock,
        status,
        image_path,
        discount_type,
        discount_value,
        discount_schedule,
        discount_start,
        discount_end,
        discount_status
    FROM tbl_products
    WHERE restaurant_id = ?
    ORDER BY product_id DESC
");

if (!$stmt) {
    error_log(
        "get_public_products.php products prepare error: " .
        $conn->error
    );

    respond_json([
        "success" => false,
        "message" => "Unable to load products."
    ], 500);
}

$stmt->bind_param(
    "i",
    $restaurant_id
);

if (!$stmt->execute()) {
    error_log(
        "get_public_products.php execute error: " .
        $stmt->error
    );

    $stmt->close();

    respond_json([
        "success" => false,
        "message" => "Unable to load products."
    ], 500);
}

$result = $stmt->get_result();

$products = [];

/*
 * One timestamp is enough for all products in this request.
 * This keeps the original working SQL/add-on logic unchanged.
 */
$currentDateTime =
    new DateTime(
        "now",
        $promotionTimezone
    );

while ($row = $result->fetch_assoc()) {
    $productId = (int) (
        $row["product_id"] ?? 0
    );

    $stock = max(
        0,
        (int) (
            $row["stock"] ?? 0
        )
    );

    $regularPrice = round(
        max(
            0,
            (float) (
                $row["price"] ?? 0
            )
        ),
        2
    );

    /* =====================================================
       PRODUCT STATUS
    ===================================================== */

    $statusValue = strtolower(
        trim(
            (string) (
                $row["status"] ??
                "unavailable"
            )
        )
    );

    $status =
        $statusValue === "available"
            ? "Available"
            : "Unavailable";

    /* =====================================================
       PRODUCT IMAGE
    ===================================================== */

    $imagePath =
        normalize_product_image_path(
            $row["image_path"] ?? null
        );

    /* =====================================================
       DISCOUNT TYPE
    ===================================================== */

    $discountType = strtolower(
        trim(
            (string) (
                $row["discount_type"] ??
                "none"
            )
        )
    );

    if (
        !in_array(
            $discountType,
            [
                "none",
                "percentage",
                "fixed"
            ],
            true
        )
    ) {
        $discountType = "none";
    }

    $discountValue = round(
        max(
            0,
            (float) (
                $row["discount_value"] ??
                0
            )
        ),
        2
    );

    /* =====================================================
       DISCOUNT SCHEDULE
    ===================================================== */

    $discountSchedule = strtolower(
        trim(
            (string) (
                $row["discount_schedule"] ??
                "permanent"
            )
        )
    );

    if (
        !in_array(
            $discountSchedule,
            [
                "permanent",
                "scheduled"
            ],
            true
        )
    ) {
        $discountSchedule =
            "permanent";
    }

    $discountStart =
        $row["discount_start"] ??
        null;

    $discountEnd =
        $row["discount_end"] ??
        null;

    if (
        $discountStart === "" ||
        $discountStart ===
            "0000-00-00 00:00:00"
    ) {
        $discountStart = null;
    }

    if (
        $discountEnd === "" ||
        $discountEnd ===
            "0000-00-00 00:00:00"
    ) {
        $discountEnd = null;
    }

    /* =====================================================
       DISCOUNT STATUS
    ===================================================== */

    $discountStatusValue =
        strtolower(
            trim(
                (string) (
                    $row["discount_status"] ??
                    "inactive"
                )
            )
        );

    $discountStatus =
        $discountStatusValue === "active"
            ? "Active"
            : "Inactive";

    /* =====================================================
       DETERMINE ACTIVE PROMOTION
    ===================================================== */

    $isDiscountActive = false;

    if (
        $discountType !== "none" &&
        $discountValue > 0 &&
        $discountStatus === "Active"
    ) {
        if (
            $discountSchedule ===
            "permanent"
        ) {
            $isDiscountActive = true;
        } elseif (
            $discountSchedule ===
                "scheduled" &&
            $discountStart !== null &&
            $discountEnd !== null
        ) {
            try {
                $discountStartObject =
                    new DateTime(
                        $discountStart,
                        $promotionTimezone
                    );

                $discountEndObject =
                    new DateTime(
                        $discountEnd,
                        $promotionTimezone
                    );

                $isDiscountActive =
                    $currentDateTime >=
                        $discountStartObject &&
                    $currentDateTime <=
                        $discountEndObject;
            } catch (Exception $error) {
                $isDiscountActive = false;
            }
        }
    }

    /* =====================================================
       CALCULATE FINAL CUSTOMER PRICE
    ===================================================== */

    $finalPrice = $regularPrice;

    if ($isDiscountActive) {
        if (
            $discountType ===
            "percentage"
        ) {
            $finalPrice =
                $regularPrice -
                (
                    $regularPrice *
                    $discountValue /
                    100
                );
        } elseif (
            $discountType === "fixed"
        ) {
            $finalPrice =
                $regularPrice -
                $discountValue;
        }

        $finalPrice = round(
            max(
                0,
                $finalPrice
            ),
            2
        );
    }

    $discountSavings =
        $isDiscountActive
            ? round(
                max(
                    0,
                    $regularPrice -
                    $finalPrice
                ),
                2
            )
            : 0.00;

    /* =====================================================
       PUBLIC RESPONSE
    ===================================================== */

    $publicProductName = (string) ($row["product_name"] ?? "Unnamed Product");
    $publicCategory = (string) ($row["category"] ?? "Uncategorized");
    $publicSize = trim((string) ($row["size"] ?? ""));
    $productGroupKey = strtolower(trim($publicCategory)) . "::" . strtolower(trim($publicProductName));

    $products[] = [
        "id" =>
            $productId,

        "product_id" =>
            $productId,

        "name" => $publicProductName,
        "product_name" => $publicProductName,
        "group_key" => $productGroupKey,
        "variant_label" => $publicSize !== "" ? $publicSize : "Standard",
        "category" => $publicCategory,

        "description" => trim(
            (string) (
                $row["description"] ?? ""
            )
        ),

        "item_type" =>
            strtolower(
                trim(
                    (string) (
                        $row["item_type"] ??
                        "menu_item"
                    )
                )
            ) === "add_on"
                ? "add_on"
                : "menu_item",

        "addon_ids" => [],

        "size" => $publicSize,

        "price" =>
            $regularPrice,

        "regular_price" =>
            $regularPrice,

        "final_price" =>
            $finalPrice,

        "discounted_price" =>
            $finalPrice,

        "discount_savings" =>
            $discountSavings,

        "discount_type" =>
            $discountType,

        "discount_value" =>
            $discountValue,

        "discount_schedule" =>
            $discountSchedule,

        "discount_start" =>
            $discountStart,

        "discount_end" =>
            $discountEnd,

        "discount_status" =>
            $discountStatus,

        "is_discount_active" =>
            $isDiscountActive,

        "stock" =>
            $stock,

        "status" =>
            $status,

        "image_path" =>
            $imagePath,

        "image" =>
            $imagePath
    ];
}

$stmt->close();

/* Product-group add-on assignments. */
$linkStmt = $conn->prepare("
    SELECT
        product_name,
        product_category,
        addon_product_id
    FROM tbl_product_addon_links
    WHERE restaurant_id = ?
");

if ($linkStmt) {
    $linkStmt->bind_param("i", $restaurant_id);

    if ($linkStmt->execute()) {
        $addonMap = [];
        $linkResult = $linkStmt->get_result();

        while ($linkRow = $linkResult->fetch_assoc()) {
            $key =
                mb_strtolower(trim((string)$linkRow["product_category"])) .
                "::" .
                mb_strtolower(trim((string)$linkRow["product_name"]));

            $addonMap[$key][] =
                (int)$linkRow["addon_product_id"];
        }

        foreach ($products as &$product) {
            if (($product["item_type"] ?? "menu_item") !== "menu_item") {
                continue;
            }

            $key =
                mb_strtolower(trim((string)($product["category"] ?? ""))) .
                "::" .
                mb_strtolower(trim((string)($product["product_name"] ?? "")));

            $product["addon_ids"] =
                array_values(
                    array_unique(
                        $addonMap[$key] ?? []
                    )
                );
        }

        unset($product);
    }

    $linkStmt->close();
}

respond_json([
    "success" => true,

    "restaurant" => [
        "restaurant_id" =>
            (int) $restaurant["restaurant_id"],

        "name" =>
            (string) $restaurant["name"],

        "business_status" =>
            $business_status,

        "customer_status" =>
            (string) $availability["customer_status"],

        "availability_reason" =>
            (string) $availability["availability_reason"],

        "opening_hours" =>
            $opening_hours,

        "is_accepting_orders" =>
            $is_accepting_orders
    ],

    "products" =>
        $products
]);